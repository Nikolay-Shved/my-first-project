#!/usr/bin/env python3

from brain_games.cli import welcome_user

welcome_user()
