from brain_games.cli import welcome_user

welcome_user()

brain_games()

